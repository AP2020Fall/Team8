package sample.model.platoModel;

public class Message {
    private String message;

    public Message(String message) {
        this.message = message;
    }
}
