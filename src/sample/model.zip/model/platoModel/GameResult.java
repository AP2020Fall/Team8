package sample.model.platoModel;

public enum GameResult {
    WIN,LOSE,MATCH ;
}
