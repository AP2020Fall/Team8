package sample.model.platoModel;

import java.awt.*;

public class DBGame {
    private Player player1;
    private Point point;
    private Player player2;
    private Player next;
    private  Player whoseTurn;
    private boolean hasMoved;
    private int player1CurrScore;
    private  int player2CurrScore;
    private int player1FinalScore;
    private int player2FinalScore;
    //change type to int
    public void isLineValid(int x1,int y1,int x2,int y2){

    }
    public void calculateScore(){

    }
    public void isSquared(){}

    public void drawLine(){}
    public void drawLineVisual(){}
    public void setMoves(){
    }
}
