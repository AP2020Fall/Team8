package sample.model.platoModel;

public enum WinSituation {
    WIN,LOSE,EQUAL
}

