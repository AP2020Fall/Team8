package sample.model.platoModel;
public class DotsAndBoxes{}